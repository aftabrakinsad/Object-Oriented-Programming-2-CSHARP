﻿using DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace DAL.Tables
{
    public class Infos
    {
        //show - select * from INFO;
        public List<Info> Get()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\mazid\source\repos\CRUD\DB\Test.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();

            string query = "select * from INFO";
            SqlCommand cmd = new SqlCommand(query, conn);

            List<Info> data = new List<Info>();
            SqlDataReader reader = cmd.ExecuteReader();

            while(reader.Read())

            {
                Info temp = new Info();
                temp.Name = reader.GetString(reader.GetOrdinal("NAME"));
                temp.City = reader.GetString(reader.GetOrdinal("CITY"));
                temp.Country = reader.GetString(reader.GetOrdinal("COUNTRY"));

                data.Add(temp);

            }

            return data;
        }

        //insert
        void Add()
        {
            //necessary codes for inserting into db
        }

        //update
        void update()
        {
            //necessary codes for updating into db
        }

        //delete
        void Delete()
        {
            //necessary codes for deleting from db
        }

        //search
        void Search()
        {
            //necessary codes for search from db
        }

    }
}
