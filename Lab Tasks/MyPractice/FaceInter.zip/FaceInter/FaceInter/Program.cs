﻿using System;

namespace FaceInter
{
    class Program
    {
        static void Main(string[] args)
        {
            Main m1 = new Main();
            //m1.IAddition.operation(3, 2);

            Console.WriteLine();

            Console.ReadKey();
        }
    }
}
