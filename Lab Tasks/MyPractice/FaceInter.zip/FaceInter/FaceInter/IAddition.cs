﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FaceInter
{
    interface IAddition
    {
        void operation(int x, int y)
        {

        }
    }
}
