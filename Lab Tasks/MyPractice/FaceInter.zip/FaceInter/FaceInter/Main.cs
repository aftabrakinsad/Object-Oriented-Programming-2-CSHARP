﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FaceInter
{
    class Main : IAddition, ISubtraction
    {
        void IAddition.operation(int x, int y)
        {
            Console.WriteLine(x + y);
        }

        void ISubtraction.operation(int x, int y)
        {
            Console.WriteLine(x - y);
        }
    }
}
