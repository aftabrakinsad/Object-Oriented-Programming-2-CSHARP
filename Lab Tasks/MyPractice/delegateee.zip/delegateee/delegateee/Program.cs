﻿using System;

namespace delegateee
{

    //Delegate
    public delegate void SampleDel(int a, int b);
    class Calculator
    {
        public void addition(int a, int b)
        {
            int result = a + b;
            Console.WriteLine("Addition: " + result);
        }
        public void subtraction(int a, int b)
        {
            int result = a - b;
            Console.WriteLine("Subtraction: " + result);
        }
        public void multiplication(int a, int b)
        {
            int result = a * b;
            Console.WriteLine("Subtraction: " + result);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Calculator c1 = new Calculator();
            c1.addition(10, 5);// usual approach
            SampleDel del = c1.addition;
            del(10, 5);//using delegate
            del = c1.subtraction;
            del(10, 5);

            Console.ReadKey();
        }
    }
}