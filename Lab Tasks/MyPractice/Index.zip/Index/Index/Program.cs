﻿using System;

namespace Index
{
    class Student
    {
        private string[] arr = new string[3];

        //Indexer
        public string this[int i]
        {
            set { arr[i]= value; }
            get { return arr[i]; }
        }

        //Indexer Overload
        public string this[String name]
        {
            get
            {
                foreach(string s1 in arr)
                {
                    if(s1.ToLower() == name.ToLower())
                    {
                        return s1.ToUpper();
                    }
                }
                return null;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Student slist = new Student();

            slist[0] = "ABC";
            slist[1] = "bac";
            slist[2] = "cab";

            for(int i= 0; i <3 ; i++)
            {
                Console.WriteLine(slist[i]);
            }

            Console.WriteLine(slist["abc"]);
            Console.ReadKey();
        }
    }
}
