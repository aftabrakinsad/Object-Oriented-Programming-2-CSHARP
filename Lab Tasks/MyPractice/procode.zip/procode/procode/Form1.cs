﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace procode
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection scon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\OBJECT ORIENTED PROGRAMMING 2\Final Term\MyPractice\LoginDB\DB\LoginDb.mdf;Integrated Security=True;Connect Timeout=30");
            string que = "SELECT * FROM Login_table WHERE Code ='" + textBox1.Text.Trim() + "'";

            SqlDataAdapter sda = new SqlDataAdapter(que, scon);

            DataTable dtbl = new DataTable();

            sda.Fill(dtbl);

            if(textBox1.Text == "SELECT Code FROM Login_table WHERE PASS = 7956")
            {
                panel2.BringToFront();
            }

        }
    }
}
