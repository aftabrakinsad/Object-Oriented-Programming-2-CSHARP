﻿CREATE TABLE Login_table
(
	Username VARCHAR(50) NOT NULL,
	PASS NVARCHAR(50) NOT NULL,
	Code NVARCHAR(50) NOT NULL
);

INSERT INTO Login_table VALUES('rakinsadaftab', '7956', '20419911');
INSERT INTO Login_table VALUES('fatemaaftab', '7000', '20411111');

SELECT * FROM Login_table