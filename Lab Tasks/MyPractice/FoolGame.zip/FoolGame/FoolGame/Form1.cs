﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoolGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 nextForm = new Form2();
            nextForm.ShowDialog();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if(keyData == Keys.Space)
            {
                Form2 notfool = new Form2();
                this.Hide();
                notfool.Show();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        int a = 0;
        private void button1_mouseEnter(object sender, EventArgs e)
        {
            Random p = new Random();
            a++;
            Point point = new Point(
            int.Parse(p.Next(700).ToString()),
            int.Parse(p.Next(400).ToString())
            );
            button1.Location = point;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Tag = this;
            form3.Show();
            Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
