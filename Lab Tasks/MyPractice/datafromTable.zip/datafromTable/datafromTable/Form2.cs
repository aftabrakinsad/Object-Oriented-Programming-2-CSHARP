﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace datafromTable
{
    public partial class Form2 : Form
    {
        SqlConnection scon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\OBJECT ORIENTED PROGRAMMING 2\Final Term\MyPractice\LoginDB\DB\LoginDb.mdf;Integrated Security=True;Connect Timeout=30");
        public Form2()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.BringToFront();

            scon.Open();
            string que = "SELECT PASS FROM Login_table WHERE USERNAME = 'rakinsadaftab'";
            SqlCommand cmd = new SqlCommand(que, scon);
            SqlDataAdapter sda = new SqlDataAdapter(que, scon);
            DataTable dt = new DataTable();

            sda.Fill(dt);
            if (textBox1.Text == que)
            {
                //panel2.BringToFront();
            }
            /*else
            {
                MessageBox.Show("Wrong password");
            }*/
            scon.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel2.BringToFront();
        }
    }
}
