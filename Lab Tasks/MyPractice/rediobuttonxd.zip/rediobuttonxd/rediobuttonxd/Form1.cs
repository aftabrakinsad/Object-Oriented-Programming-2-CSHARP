﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace rediobuttonxd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string code = string.Empty;
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection scon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\OBJECT ORIENTED PROGRAMMING 2\Final Term\MyPractice\rediobuttonxd\DB\code.mdf;Integrated Security=True;Connect Timeout=30");
            scon.Open();
            string que = "insert into  [dbo].[INFO] values(@Code)";
            SqlCommand scmd = new SqlCommand(que, scon);
            scmd.Parameters.AddWithValue("@Code", code);
            scmd.ExecuteNonQuery();
            MessageBox.Show("Registered");
            scon.Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            code = "XD";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            code = "DX";
        }
    }
}
